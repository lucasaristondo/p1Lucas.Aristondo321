
package centroentrenamiento;

public class ClaseGrupal extends Actividad implements Programable {

    private int maxParticipantes;

   
     
    public ClaseGrupal(String nombre, String entrenador, NivelIntensidad nivel, int maxParticipantes) {
        super(nombre, entrenador, nivel);
            this.maxParticipantes = maxParticipantes;
    }

    
    public int getMaxParticipantes() 
        { return maxParticipantes; }

    @Override
    public void programar() {
        System.out.println("Se programo la clase grupal: " + getNombre());
    }

    @Override
    public String toString() {
        return "ClaseGrupal [ nombre = " + getNombre() + ", entrenador = " + getEntrenador() + ", intensidad = " + getNivel() + ", maxParticipantes = " + maxParticipantes + "]";
    }
}