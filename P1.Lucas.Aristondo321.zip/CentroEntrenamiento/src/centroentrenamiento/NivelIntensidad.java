
package centroentrenamiento;


public enum NivelIntensidad {
     BAJA, MEDIA, ALTA
}
