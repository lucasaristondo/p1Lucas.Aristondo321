
package centroentrenamiento;

import java.util.List;

public class CentroEntrenamiento {

    public static void main(String[] args) {
        CentroActividades centro = new CentroActividades("Alto Rendimiento Sur");

        try {
            centro.agregarActividad(new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25));
            centro.agregarActividad(new RutinaPersonalizada("Plan Fuerza Inicial", "Martin Diaz", NivelIntensidad.MEDIA, 8));
            centro.agregarActividad(new EvaluacionFisica("Evaluacion Ingreso", "Carla Suarez", NivelIntensidad.BAJA, 78));
            centro.agregarActividad(new RutinaPersonalizada("Plan Resistencia", "Laura Gomez", NivelIntensidad.ALTA, 6));
            centro.agregarActividad(new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20));
        } catch (ActividadDuplicadaException e) {
            System.out.println("No se pudo agregar la actividad: " + e.getMessage());
        }

        System.out.println("Actividades registradas:");
        mostrarActividades(centro.obtenerActividades());

        System.out.println();
        System.out.println("Actividades programables:");
        programarActividades(centro.obtenerActividades());

        System.out.println();
        System.out.println("Informes generados:");
        generarInformesDesdeMain(centro.obtenerActividades());

        System.out.println();
        System.out.println("Actividades de intensidad ALTA:");
        mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA));
    }

    private static void mostrarActividades(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            System.out.println(a);
        }
    }

    private static void programarActividades(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            if (a instanceof Programable) {
                ((Programable) a).programar();
            } else {
                System.out.println("La actividad '" + a.getNombre() + "' no puede programarse.");
            }
        }
    }

    private static void generarInformesDesdeMain(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            if (a instanceof GeneradorInforme) {
                ((GeneradorInforme) a).generarInforme();
            } else {
                System.out.println("La actividad '" + a.getNombre() + "' no genera informe.");
            }
        }
    }
}