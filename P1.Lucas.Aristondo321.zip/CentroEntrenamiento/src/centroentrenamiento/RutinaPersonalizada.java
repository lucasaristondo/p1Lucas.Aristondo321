
package centroentrenamiento;

public class RutinaPersonalizada extends Actividad implements Programable, GeneradorInforme {

    private int duracionSemanas;

    public RutinaPersonalizada(String nombre, String entrenador, NivelIntensidad nivel, int duracionSemanas) {
        super(nombre, entrenador, nivel);
        this.duracionSemanas = duracionSemanas;
    }

   
    public int getDuracionSemanas() {
        return duracionSemanas; }

    @Override
    public void programar() {
        System.out.println(" Se programo la rutina personalizada: " + getNombre());
    }

    @Override
    public void generarInforme() {
        System.out.println(" Informe de rutina personalizada : " + getNombre() + ". Duracion estimada: " + duracionSemanas + " semanas.");
    }

    @Override
    public String toString() {
        return "RutinaPersonalizada [ nombre = " + getNombre() + ", entrenador = " + getEntrenador() + ", intensidad = " + getNivel() + ", duracionSemanas = "  + duracionSemanas + "]";
    }
}