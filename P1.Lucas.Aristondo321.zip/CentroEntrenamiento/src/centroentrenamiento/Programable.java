
package centroentrenamiento;


public interface Programable {
    void programar();
}
