
package centroentrenamiento;

import java.util.Objects;

public abstract class Actividad {

    private String nombre;
    private String entrenador;
    private NivelIntensidad nivel;

    public Actividad(String nombre, String entrenador, NivelIntensidad nivel) {
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.nivel = nivel;
    }

    
    public String getNombre() 
        { return nombre; }

    public String getEntrenador() 
        { return entrenador; }

    public NivelIntensidad getNivel() 
        { return nivel; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Actividad)) return false;
        Actividad otra = (Actividad) obj;
        return Objects.equals(this.nombre, otra.nombre)
            && Objects.equals(this.entrenador, otra.entrenador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, entrenador);
    }
}