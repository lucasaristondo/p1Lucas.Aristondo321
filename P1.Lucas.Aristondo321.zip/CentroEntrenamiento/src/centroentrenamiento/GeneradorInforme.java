
package centroentrenamiento;


public interface GeneradorInforme {
    void generarInforme();
}
