
package centroentrenamiento;

import java.util.ArrayList;
import java.util.List;


public class CentroActividades {

    private String nombre;
    private ArrayList<Actividad> actividades;

   
    public CentroActividades(String nombre) {
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }

    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        if (actividades.contains(actividad)) {
            throw new ActividadDuplicadaException(actividad.getNombre(), actividad.getEntrenador());
        }
        actividades.add(actividad);
    }

    public List<Actividad> obtenerActividades() {
        return new ArrayList<>(actividades);
    }

    public List<Actividad> filtrarPorNivel(NivelIntensidad nivel) {
        ArrayList<Actividad> resultado = new ArrayList<>();
        for (Actividad a : actividades) {
            if (a.getNivel() == nivel) {
                resultado.add(a);
            }
        }
        return resultado;
    }

   
    public String getNombre() { return nombre; }
}
