
package centroentrenamiento;


public class ActividadDuplicadaException extends Exception {
    
    public ActividadDuplicadaException(String nombre, String entrenador) {
        super(" Ya existe una actividad con nombre '" + nombre + "' y entrenador '" + entrenador + "'.");
    }
}